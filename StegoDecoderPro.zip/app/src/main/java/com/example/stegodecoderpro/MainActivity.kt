package com.example.stegodecoderpro

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.stegodecoderpro.databinding.ActivityMainBinding
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            loadImageAndDecode(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSelectImage.setOnClickListener {
            selectImageLauncher.launch("image/*")
        }
    }

    private fun loadImageAndDecode(uri: Uri) {
        try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            if (bitmap == null) {
                Toast.makeText(this, "Resim yüklenemedi", Toast.LENGTH_SHORT).show()
                return
            }
            binding.imgPreview.setImageBitmap(bitmap)

            val decodedText = decodeLSB(bitmap)
            if (decodedText.isEmpty()) {
                binding.tvResult.text = "Gizli mesaj bulunamadı."
            } else {
                binding.tvResult.text = decodedText
            }

        } catch (e: Exception) {
            Toast.makeText(this, "Hata oluştu: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun decodeLSB(bitmap: Bitmap): String {
        val width = bitmap.width
        val height = bitmap.height

        val byteList = mutableListOf<Byte>()
        var currentByte = 0
        var bitCount = 0

        loop@ for (y in 0 until height) {
            for (x in 0 until width) {
                val pixel = bitmap.getPixel(x, y)
                // Renk kanallarının (Kırmızı, Yeşil, Mavi) en düşük bitini sırayla alıyoruz
                // Bu örnek için sadece mavi kanalının LSB'sini kullanalım:
                val lsb = pixel and 1
                currentByte = currentByte shl 1 or lsb
                bitCount++
                if (bitCount == 8) {
                    if (currentByte == 0) break@loop // Null byte gördüğümüzde son
                    byteList.add(currentByte.toByte())
                    currentByte = 0
                    bitCount = 0
                }
            }
        }

        return byteList.toByteArray().toString(Charsets.UTF_8)
    }
}